# Animations Reactions

Animations & Reactions is a modern, fully interactive wearable app that showcases the most common social media animation and reaction patterns for HarmonyOS NEXT wearable devices, developed in ArkTS.

# Preview

<img src="./screenshots/ss1.png" width="24%"/>
<img src="./screenshots/ss3.png" width="24%"/>
<img src="./screenshots/ss2.png" width="24%"/>
<img src="./screenshots/ss4.png" width="24%"/>
<img src="./screenshots/ss5.png" width="24%"/>

# Use Cases
- Like (Heart) Animation
- Emoji Reaction Animation
- Notification (Banner) Animation
- Message Bubble Animation
- Badge / Achievement Animation

# Tech Stack

Languages: ArkTS
Frameworks: HarmonyOS SDK 5.1.0(18)
Tools: DevEco Studio Vers 5.1.0.820
Libraries: `@kit.ArkUI`

# Directory Structure

```
entry/src/main/ets/
|---entryability
|---|---EntryAbility
|---entrybackupability
|---|---EntryBackupAbility
|---pages
|---|---BadgeAnimationPage
|---|---EmojiReactionPage
|---|---Index
|---|---LikeAnimationPage
|---|---MessageAnimationPage
|---|---NotificationAnimationPage
|---utils
|---|---NavigationUtil
```

# Constraints and Restrictions

## Supported Devices

- Huawei Watch 5

# LICENSE

AnimationsReactions is distributed under the terms of the MIT License.
See the [LICENSE](/LICENSE) for more information.
